//Calling ProductList and searchbox from the HTML file
//const ProductList = document.getElementById('ProductList');
const search_box = document.getElementById('search_box');
//var products array
var products = [
    {
        id:1,
        title:'Different Book',
        price: 10.00,
        rating: 3,
        author: 'Sally Clarkson',
        image: 'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\41tTZ6cwHHL.jpg'
    },
    {
        id:2,
        title:'This Time Will Be Different Book',
        price: 20.50,
        rating: 1,
        author: 'Misa Sugira',
        image: 'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\41716638.jpg'
    },
    {
        id:3,
        title:'The Imperfections of Memory Book',
        price: 20.50,
        rating: 2,
        author: 'Angellina Aludo',
        image: 'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\contemporary-fiction-night-time-book-cover-design-template-1be47835c3058eb42211574e0c4ed8bf_screen.jpg'
    },
    {
        id:4,
        title:'Pet the Cat Book',
        price: 55.99,
        rating: 5,
        author: 'Eric Litwin',
        image: 'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\pete-the-cat.jpg'
    },
    {
        id:5,
        title:'The King of Drugs Book',
        price: 9.50,
        rating: 2,
        author: 'Nora Burrtte',
        image:'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\action-thriller-book-cover-design-template-3675ae3e3ac7ee095fc793ab61b812cc_screen.jpg'
    },
];

window.onload = function(){ 
    //Getting the product Id in the url
    var url_id = window.location.search.split('id=')[1];
        if(url_id !== '') {
            products.forEach(function(product){
                if(product.id == url_id){
                    document.querySelector('#title').innerHTML = product.title;
                    document.querySelector('#author').innerHTML = product.author; 
                    document.querySelector('#price').innerHTML = product.price;
                    document.querySelector('#rating').innerHTML = product.rating;
                    document.querySelector('#image').src = product.image;
                }
            });
        }
};