
//const productList = document.getElementById('productList');
const search_box = document.getElementById('search_box');

//Vars products array
var products = [
{
        id:1,
        title:'Different Book',
        author: 'Sally Clarkson',
        price: 10.00,
        rating: 3,
        image: 'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\41tTZ6cwHHL.jpg'
    },
    {
        id:2,
        title:'This Time Will be Different Book',
        author: 'Misa Sugira',
        price: 50.00,
        rating: 1,
        image: 'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\41716638.jpg'
    },
    {
        id:3,
        title:'The Imperfections of Memory Book',
        author: 'Angellina Aludo',
        price: 20.50,
        rating: 2,
        image: 'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\contemporary-fiction-night-time-book-cover-design-template-1be47835c3058eb42211574e0c4ed8bf_screen.jpg'
    },
    {
        id:4,
        title:'Pet the Cat Book',
        author: 'Eric Litwin',
        price: 55.99,
        rating: 5,
        image: 'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\pete-the-cat.jpg'
    },
    {
        id:5,
        title:'The King of Drugs Book',
        author: 'Nora Burrtte',
        price: 9.50,
        rating: 2,
        image:'C:\Users\abuma\OneDrive\Desktop\Ambarka Raheel Project_P 1\assets\img\action-thriller-book-cover-design-template-3675ae3e3ac7ee095fc793ab61b812cc_screen.jpg'
    },
    {
        id:6,
        title:'Cat in the Hat',
        author: 'Nora Burrtte',
        price: 9.50,
        rating: 2,
        image: "https://upload.wikimedia.org/wikipedia/en/thumb/d/db/Cat_in_the_hat.jpg/220px-Cat_in_the_hat.jpg"
    }
    ];

//template for search results
var product_template = `
<div class = "product">
        <h3><a href="product.html?id=<ID>"><TITLE></a></h3>
        <a href = "product.html?id=<ID>"><img src ="<IMAGE>" style="width: 400px;"></a>
        <p>Price: $<PRICE></p>
        <p>Rating: <RATING>/5</p>
</div>;`
    
window.onload = function(){ 
    var search = window.location.search.split('text=')[1];
    document.querySelector('#search_box').value = search;

    if(search !== '') {
         
        //Keep checking for each product in the array
        products.forEach(function(product){

            if(product.title.toLowerCase().includes(search.toLowerCase())){

                var p = product_template.replaceAll('<ID>', product.id);
                p = p.replace('<TITLE>', product,title);
                P = p.replace('<AUTHOR>', product,author);
                P = p.replace('<IMAGE>', product,image);
                P = p.replace('<PRICE>', product,price);
                p = p.replace('<RATING>', product.rating);
                
                document.querySelector('#productList').innerHTML += p;
            }
       });
    }
};